kodi plugin for olevod

Credits:

js2py: https://github.com/PiotrDabkowski/Js2Py
cfscrape: https://github.com/Anorov/cloudflare-scrape

using command outside of this folder to zip

```shell
rm oversea.zip
zip -r -0  oversea.zip plugin.video.overseaplayer -x "*/.*" -x "*/*.pyo"
```